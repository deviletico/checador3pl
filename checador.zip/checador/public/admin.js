'use strict';

// Panel de administración: tablero del día, reportes, personal, incidencias y ajustes.

const app = document.getElementById('app');
const ctx = { settings: null, tab: 'hoy', panel: null };

const TABS = [
  ['hoy', 'Hoy'],
  ['reporte', 'Reporte'],
  ['personal', 'Personal'],
  ['incidencias', 'Incidencias'],
  ['ajustes', 'Ajustes'],
];

const KIND_LABELS = {
  festivo: 'Día festivo (todos)',
  justificada: 'Falta justificada',
  vacaciones: 'Vacaciones',
  incapacidad: 'Incapacidad',
  descanso: 'Día de descanso',
};

let refreshTimer = null;

function notice(kind, text) {
  return h('p', { class: `notice ${kind}`, role: kind === 'bad' ? 'alert' : 'status', text });
}

// Botón que pide una segunda pulsación antes de ejecutar acciones destructivas.
function confirmButton(label, onConfirm, cls = 'btn danger sm') {
  let armed = false;
  let timer = null;
  const btn = h('button', {
    class: cls,
    type: 'button',
    text: label,
    onclick: async () => {
      if (!armed) {
        armed = true;
        btn.textContent = '¿Seguro?';
        timer = setTimeout(() => {
          armed = false;
          btn.textContent = label;
        }, 3500);
        return;
      }
      clearTimeout(timer);
      btn.disabled = true;
      await onConfirm();
    },
  });
  return btn;
}

// ---------------------------------------------------------------------------
// Acceso
// ---------------------------------------------------------------------------
function renderLogin(message) {
  clearInterval(refreshTimer);
  clear(app);
  app.className = 'wrap narrow';
  const pwd = h('input', { id: 'pwd', type: 'password', autocomplete: 'current-password', required: true });
  const err = h('p', { class: `notice bad ${message ? '' : 'hidden'}`, role: 'alert', text: message || '' });
  const btn = h('button', { class: 'btn primary', type: 'submit', text: 'Entrar' });
  app.append(
    h(
      'form',
      {
        class: 'card',
        onsubmit: async (ev) => {
          ev.preventDefault();
          btn.disabled = true;
          err.classList.add('hidden');
          try {
            await api('/api/admin/login', { method: 'POST', body: { password: pwd.value } });
            await boot();
          } catch (e) {
            err.textContent = e.message;
            err.classList.remove('hidden');
            pwd.value = '';
            btn.disabled = false;
          }
        },
      },
      h('div', {}, h('h1', { text: 'Administración' }), h('p', { class: 'muted', text: 'Checador de entradas y salidas' })),
      h('label', {}, 'Contraseña', pwd),
      err,
      btn
    )
  );
}

async function guard(fn) {
  try {
    return await fn();
  } catch (e) {
    if (e.status === 401) {
      renderLogin('Tu sesión terminó. Inicia sesión de nuevo.');
      return undefined;
    }
    throw e;
  }
}

// ---------------------------------------------------------------------------
// Estructura
// ---------------------------------------------------------------------------
function renderShell() {
  clearInterval(refreshTimer);
  clear(app);
  app.className = 'wrap wide';
  ctx.panel = h('div', { class: 'wrap wide', style: 'max-width:none' });
  const tabs = h(
    'div',
    { class: 'tabs', role: 'tablist' },
    TABS.map(([id, label]) =>
      h('button', {
        class: 'tab',
        role: 'tab',
        id: `tab-${id}`,
        'aria-selected': String(ctx.tab === id),
        text: label,
        onclick: () => showTab(id),
      })
    )
  );
  app.append(
    h(
      'div',
      { class: 'row between wrap-sm' },
      h('div', {}, h('h1', { text: 'Administración' }), h('p', { class: 'muted small', text: ctx.settings.site_name })),
      h('div', { class: 'row' }, h('a', { class: 'btn sm', href: '/', text: 'Pantalla del empleado' }), h('button', {
        class: 'btn sm',
        text: 'Cerrar sesión',
        onclick: async () => {
          await api('/api/admin/logout', { method: 'POST', body: {} });
          renderLogin();
        },
      }))
    ),
    tabs,
    ctx.panel
  );
}

async function showTab(id) {
  ctx.tab = id;
  clearInterval(refreshTimer);
  for (const [t] of TABS) {
    const el = document.getElementById(`tab-${t}`);
    if (el) el.setAttribute('aria-selected', String(t === id));
  }
  clear(ctx.panel);
  const fn = { hoy: tabHoy, reporte: tabReporte, personal: tabPersonal, incidencias: tabIncidencias, ajustes: tabAjustes }[id];
  try {
    await guard(() => fn(ctx.panel));
  } catch (e) {
    ctx.panel.append(notice('bad', e.message));
  }
}

// ---------------------------------------------------------------------------
// Hoy
// ---------------------------------------------------------------------------
async function tabHoy(panel) {
  const dateInput = h('input', { id: 'hoy-fecha', type: 'date' });
  const body = h('div', {});
  const stamp = h('span', { class: 'muted small' });

  async function load() {
    const q = dateInput.value ? `?date=${dateInput.value}` : '';
    const r = await guard(() => api(`/api/admin/today${q}`));
    if (!r) return;
    dateInput.value = r.date;
    stamp.textContent = `Actualizado ${new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' })}`;
    clear(body);
    if (!r.workday) body.append(notice('', 'Domingo: no es día laborable.'));
    if (!r.rows.length) {
      body.append(h('p', { class: 'empty', text: 'No hay personal activo para esta fecha.' }));
      return;
    }
    const counts = { asistencia: 0, retardo: 0, falta: 0, pendiente: 0 };
    for (const row of r.rows) if (row.day.status in counts) counts[row.day.status] += 1;
    body.append(
      h(
        'div',
        { class: 'tiles' },
        h('div', { class: 'tile' }, h('b', { text: counts.asistencia + counts.retardo }), h('span', { text: 'Presentes' })),
        h('div', { class: `tile ${counts.retardo ? 'warn' : ''}` }, h('b', { text: counts.retardo }), h('span', { text: 'Con retardo' })),
        h('div', { class: `tile ${counts.falta ? 'bad' : ''}` }, h('b', { text: counts.falta }), h('span', { text: 'Faltas' })),
        h('div', { class: 'tile' }, h('b', { text: counts.pendiente }), h('span', { text: 'Por llegar' }))
      ),
      h(
        'div',
        { class: 'table-wrap' },
        h(
          'table',
          {},
          h('thead', {}, h('tr', {}, ['Empleado', 'Turno', 'Estado', 'Entrada', 'Salida', 'Retardo'].map((t, i) => h('th', { class: i > 2 ? 'n' : '', text: t })))),
          h(
            'tbody',
            {},
            r.rows.map(({ employee: e, day }) =>
              h(
                'tr',
                {},
                h('td', {}, h('div', { class: 'row' }, avatar(e, 'sm'), h('span', { text: e.name }))),
                h('td', { text: `${e.shift_label} ${e.shift_start}–${e.shift_end}` }),
                h('td', {}, statusChip(day.status), day.sin_salida ? h('span', { class: 'chip bad', text: 'Sin salida' }) : null),
                h('td', { class: 'n', text: day.entrada || '—' }),
                h('td', { class: 'n', text: day.salida || '—' }),
                h('td', { class: 'n', text: day.minutos_retardo ? `${day.minutos_retardo} min` : '—' })
              )
            )
          )
        )
      )
    );
  }

  panel.append(
    h(
      'div',
      { class: 'card' },
      h(
        'div',
        { class: 'row wrap-sm' },
        h('label', {}, 'Fecha', dateInput),
        h('button', { class: 'btn', text: 'Actualizar', onclick: () => load().catch((e) => body.prepend(notice('bad', e.message))) }),
        stamp
      )
    ),
    body
  );
  dateInput.addEventListener('change', () => load());
  await load();
  refreshTimer = setInterval(() => {
    if (document.visibilityState === 'visible') load().catch(() => {});
  }, 60000);
}

// ---------------------------------------------------------------------------
// Reporte
// ---------------------------------------------------------------------------
async function tabReporte(panel) {
  const from = h('input', { id: 'rep-desde', type: 'date' });
  const to = h('input', { id: 'rep-hasta', type: 'date' });
  const inactive = h('input', { id: 'rep-inactivos', type: 'checkbox', style: 'width:auto' });
  const csv = h('a', { class: 'btn', text: 'Descargar CSV', href: '#' });
  const results = h('div', { class: 'wrap wide', style: 'max-width:none' });
  const detail = h('div', {});

  function query() {
    return `from=${from.value}&to=${to.value}${inactive.checked ? '&inactive=1' : ''}`;
  }

  async function load() {
    clear(detail);
    const r = await guard(() => api(`/api/admin/report?${from.value ? query() : ''}`));
    if (!r) return;
    from.value = r.from;
    to.value = r.to;
    csv.href = `/api/admin/report.csv?${query()}`;
    clear(results);
    if (!r.rows.length) {
      results.append(h('p', { class: 'empty', text: 'No hay personal para este periodo.' }));
      return;
    }
    const heads = ['Empleado', 'Turno', 'Días trab.', 'Retardos', 'Min. retardo', 'Faltas', 'Justif.', 'Sin salida', 'Horas'];
    results.append(
      h(
        'div',
        { class: 'table-wrap' },
        h(
          'table',
          {},
          h('thead', {}, h('tr', {}, heads.map((t, i) => h('th', { class: i > 1 ? 'n' : '', text: t })))),
          h(
            'tbody',
            {},
            r.rows.map(({ employee: e, totals: t }) =>
              h(
                'tr',
                { class: 'click', tabindex: '0', onclick: () => openDetail(e.id), onkeydown: (ev) => ev.key === 'Enter' && openDetail(e.id) },
                h('td', {}, h('div', { class: 'row' }, avatar(e, 'sm'), h('span', { text: e.name }), e.active ? null : h('span', { class: 'chip', text: 'Inactivo' }))),
                h('td', { text: e.shift_label }),
                h('td', { class: 'n', text: t.dias_trabajados }),
                h('td', { class: 'n', text: t.retardos }),
                h('td', { class: 'n', text: t.minutos_retardo }),
                h('td', { class: 'n', text: t.faltas }),
                h('td', { class: 'n', text: t.justificadas }),
                h('td', { class: 'n', text: t.sin_salida }),
                h('td', { class: 'n', text: fmtHours(t.minutos_trabajados) })
              )
            )
          )
        )
      ),
      h('p', { class: 'muted small', text: 'Toca un empleado para ver el detalle por día, sus checadas y agregar correcciones.' })
    );
  }

  async function openDetail(id) {
    const d = await guard(() => api(`/api/admin/employees/${id}/detail?from=${from.value}&to=${to.value}`));
    if (!d) return;
    clear(detail);
    const t = d.totals;

    const mType = h('select', { id: 'man-tipo' }, h('option', { value: 'in', text: 'Entrada' }), h('option', { value: 'out', text: 'Salida' }));
    const mDate = h('input', { id: 'man-fecha', type: 'date', value: d.to });
    const mTime = h('input', { id: 'man-hora', type: 'time', required: true });
    const mNote = h('input', { id: 'man-nota', type: 'text', maxlength: '200', required: true, placeholder: 'Ej. Olvidó checar salida' });
    const mErr = h('p', { class: 'notice bad hidden', role: 'alert' });

    detail.append(
      h(
        'div',
        { class: 'card' },
        h(
          'div',
          { class: 'row between wrap-sm' },
          h('div', { class: 'row' }, avatar(d.employee, 'lg'), h('div', {}, h('h2', { text: d.employee.name }), h('p', { class: 'muted small', text: `Turno ${d.employee.shift_label.toLowerCase()} · del ${fmtDate(d.from)} al ${fmtDate(d.to)}` }))),
          h('button', { class: 'btn ghost sm', text: 'Cerrar', onclick: () => clear(detail) })
        ),
        h(
          'div',
          { class: 'tiles' },
          h('div', { class: 'tile' }, h('b', { text: t.dias_trabajados }), h('span', { text: 'Días trabajados' })),
          h('div', { class: `tile ${t.retardos ? 'warn' : ''}` }, h('b', { text: t.retardos }), h('span', { text: 'Retardos' })),
          h('div', { class: `tile ${t.faltas ? 'bad' : ''}` }, h('b', { text: t.faltas }), h('span', { text: 'Faltas' })),
          h('div', { class: 'tile' }, h('b', { text: fmtHours(t.minutos_trabajados) }), h('span', { text: 'Horas trabajadas' }))
        ),
        h('h3', { text: 'Por día' }),
        d.days.length
          ? h(
              'div',
              { class: 'list' },
              [...d.days].reverse().map((day) =>
                h(
                  'div',
                  { class: 'item' },
                  h('span', { class: 'when', text: fmtDate(day.date) }),
                  h('span', { class: 'what', text: day.entrada ? `${day.entrada} – ${day.salida || 'sin salida'}${day.salida ? ` · ${fmtHours(day.minutos_trabajados)} h` : ''}${day.minutos_retardo ? ` · +${day.minutos_retardo} min` : ''}` : day.note || '' }),
                  statusChip(day.status)
                )
              )
            )
          : h('p', { class: 'empty', text: 'Sin días laborables en el periodo.' }),
        h('h3', { text: 'Checadas' }),
        d.punches.length
          ? h(
              'div',
              { class: 'list' },
              d.punches.map((p) =>
                h(
                  'div',
                  { class: 'item' },
                  h('span', { class: 'when', text: `${fmtDate(p.date)}` }),
                  h(
                    'span',
                    { class: 'what' },
                    `${p.time} · ${p.type === 'in' ? 'Entrada' : 'Salida'} · `,
                    p.source === 'manual' ? `manual: ${p.note}` : `a ${p.distance_m} m, precisión ±${p.accuracy_m} m`
                  ),
                  confirmButton('Eliminar', async () => {
                    await guard(() => api(`/api/admin/punches/${p.id}`, { method: 'DELETE' }));
                    await load();
                    await openDetail(id);
                  })
                )
              )
            )
          : h('p', { class: 'empty', text: 'Sin checadas en el periodo.' }),
        h('h3', { text: 'Agregar checada manual' }),
        h(
          'form',
          {
            class: 'wrap wide',
            style: 'max-width:none',
            onsubmit: async (ev) => {
              ev.preventDefault();
              mErr.classList.add('hidden');
              try {
                await guard(() =>
                  api('/api/admin/punches', {
                    method: 'POST',
                    body: { employee_id: id, type: mType.value, date: mDate.value, time: mTime.value, note: mNote.value },
                  })
                );
                await load();
                await openDetail(id);
              } catch (e) {
                mErr.textContent = e.message;
                mErr.classList.remove('hidden');
              }
            },
          },
          h(
            'div',
            { class: 'form-grid' },
            h('label', {}, 'Tipo', mType),
            h('label', {}, 'Fecha', mDate),
            h('label', {}, 'Hora', mTime),
            h('label', {}, 'Motivo', mNote)
          ),
          mErr,
          h('div', {}, h('button', { class: 'btn primary', type: 'submit', text: 'Guardar checada' }))
        )
      )
    );
    detail.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  panel.append(
    h(
      'div',
      { class: 'card' },
      h(
        'div',
        { class: 'row wrap-sm', style: 'align-items:end' },
        h('label', {}, 'Desde', from),
        h('label', {}, 'Hasta', to),
        h('label', { style: 'display:flex;align-items:center;gap:8px;font-weight:500' }, inactive, 'Incluir inactivos'),
        h('button', { class: 'btn primary', text: 'Ver reporte', onclick: () => load().catch((e) => results.prepend(notice('bad', e.message))) }),
        csv
      ),
      h('p', { class: 'muted small', text: 'Faltas: días laborables (lunes a sábado) sin entrada, desde la fecha de ingreso y sin incidencia registrada.' })
    ),
    results,
    detail
  );
  await load();
}

// ---------------------------------------------------------------------------
// Personal
// ---------------------------------------------------------------------------
async function tabPersonal(panel) {
  const list = h('div', { class: 'wrap wide', style: 'max-width:none' });
  const formHost = h('div', {});

  async function load() {
    const rows = await guard(() => api('/api/admin/employees'));
    if (!rows) return;
    clear(list);
    if (!rows.length) list.append(h('p', { class: 'empty', text: 'Aún no hay personal. Agrega a la primera persona.' }));
    list.append(
      h(
        'div',
        { class: 'form-grid' },
        rows.map((e) =>
          h(
            'div',
            { class: 'card' },
            h(
              'div',
              { class: 'row' },
              avatar(e),
              h(
                'div',
                { class: 'grow' },
                h('h3', { text: e.name }),
                h('p', { class: 'muted small', text: `${e.shift_label} · ${e.shift_start}–${e.shift_end}` }),
                h('p', { class: 'muted small', text: `Ingreso: ${fmtDate(e.start_date)}` })
              ),
              h('span', { class: `chip ${e.active ? 'ok' : ''}`, text: e.active ? 'Activo' : 'Inactivo' })
            ),
            h('div', {}, h('button', { class: 'btn sm', text: 'Editar', onclick: () => openForm(e) }))
          )
        )
      )
    );
  }

  function openForm(emp) {
    clear(formHost);
    const editing = !!emp;
    const name = h('input', { id: 'p-nombre', type: 'text', required: true, maxlength: '80', value: emp ? emp.name : '' });
    const shift = h(
      'select',
      { id: 'p-turno' },
      Object.entries(ctx.settings.shifts).map(([k, s]) => h('option', { value: k, text: `${s.label} (${s.start} a ${s.end})` }))
    );
    shift.value = emp ? emp.shift : 'matutino';
    const start = h('input', { id: 'p-ingreso', type: 'date', required: true, value: emp ? emp.start_date : '' });
    const pin = h('input', {
      id: 'p-pin',
      type: 'text',
      inputmode: 'numeric',
      pattern: '[0-9]{4,6}',
      maxlength: '6',
      autocomplete: 'off',
      required: !editing,
      placeholder: editing ? 'Déjalo vacío para conservarlo' : '4 a 6 dígitos',
    });
    const active = h('input', { id: 'p-activo', type: 'checkbox', checked: emp ? emp.active : true, style: 'width:auto' });
    let photoData = null;
    const preview = h('div', {}, avatar(emp || { name: 'Nuevo', photo_url: null }, 'lg'));
    const file = h('input', {
      id: 'p-foto',
      type: 'file',
      accept: 'image/*',
      capture: 'user',
      onchange: async () => {
        if (!file.files[0]) return;
        try {
          photoData = await photoToDataUrl(file.files[0]);
          clear(preview).append(h('img', { class: 'avatar lg', src: photoData, alt: 'Vista previa de la foto' }));
        } catch (e) {
          err.textContent = e.message;
          err.classList.remove('hidden');
        }
      },
    });
    const err = h('p', { class: 'notice bad hidden', role: 'alert' });

    if (!emp) {
      // Fecha de ingreso por defecto: hoy en la zona del centro de trabajo.
      start.value = new Intl.DateTimeFormat('en-CA', { timeZone: ctx.settings.tz }).format(new Date());
    }

    formHost.append(
      h(
        'form',
        {
          class: 'card',
          onsubmit: async (ev) => {
            ev.preventDefault();
            err.classList.add('hidden');
            const body = { name: name.value, shift: shift.value, start_date: start.value };
            if (pin.value) body.pin = pin.value;
            if (photoData) body.photo = photoData;
            if (editing) body.active = active.checked;
            try {
              await guard(() =>
                editing
                  ? api(`/api/admin/employees/${emp.id}`, { method: 'PUT', body })
                  : api('/api/admin/employees', { method: 'POST', body })
              );
              clear(formHost);
              await load();
            } catch (e) {
              err.textContent = e.message;
              err.classList.remove('hidden');
            }
          },
        },
        h('h2', { text: editing ? `Editar a ${emp.name}` : 'Agregar persona' }),
        h('div', { class: 'row wrap-sm', style: 'align-items:flex-start' }, preview, h('label', { class: 'grow' }, 'Foto', file, h('span', { class: 'hint', text: 'Toma una foto de frente; se guarda reducida.' }))),
        h(
          'div',
          { class: 'form-grid' },
          h('label', {}, 'Nombre completo', name),
          h('label', {}, 'Turno', shift),
          h('label', {}, 'Fecha de ingreso', start, h('span', { class: 'hint', text: 'Las faltas se cuentan desde esta fecha.' })),
          h('label', {}, 'PIN de checada', pin)
        ),
        editing ? h('label', { style: 'display:flex;align-items:center;gap:8px;font-weight:500' }, active, 'Activo (desmárcalo cuando deje de trabajar)') : null,
        err,
        h(
          'div',
          { class: 'row' },
          h('button', { class: 'btn primary', type: 'submit', text: 'Guardar' }),
          h('button', { class: 'btn ghost', type: 'button', text: 'Cancelar', onclick: () => clear(formHost) })
        )
      )
    );
    name.focus();
    formHost.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  panel.append(h('div', {}, h('button', { class: 'btn primary', text: 'Agregar persona', onclick: () => openForm(null) })), formHost, list);
  await load();
}

// ---------------------------------------------------------------------------
// Incidencias
// ---------------------------------------------------------------------------
async function tabIncidencias(panel) {
  const employees = await guard(() => api('/api/admin/employees'));
  if (!employees) return;
  const kind = h('select', { id: 'i-tipo' }, ctx.settings.exception_kinds.map((k) => h('option', { value: k, text: KIND_LABELS[k] || k })));
  const emp = h(
    'select',
    { id: 'i-empleado' },
    h('option', { value: '', text: 'Todos (solo festivos)' }),
    employees.filter((e) => e.active).map((e) => h('option', { value: String(e.id), text: e.name }))
  );
  const from = h('input', { id: 'i-desde', type: 'date', required: true });
  const to = h('input', { id: 'i-hasta', type: 'date', required: true });
  const note = h('input', { id: 'i-nota', type: 'text', maxlength: '200', placeholder: 'Ej. Cita médica, Día de la Constitución' });
  const err = h('p', { class: 'notice bad hidden', role: 'alert' });
  const list = h('div', {});

  const today = new Intl.DateTimeFormat('en-CA', { timeZone: ctx.settings.tz }).format(new Date());
  from.value = today;
  to.value = today;
  from.addEventListener('change', () => {
    if (!to.value || to.value < from.value) to.value = from.value;
  });
  kind.addEventListener('change', () => {
    if (kind.value === 'festivo') emp.value = '';
  });

  async function load() {
    const rows = await guard(() => api('/api/admin/exceptions'));
    if (!rows) return;
    clear(list);
    if (!rows.length) {
      list.append(h('p', { class: 'empty', text: 'No hay incidencias registradas.' }));
      return;
    }
    list.append(
      h(
        'div',
        { class: 'card' },
        h(
          'div',
          { class: 'list' },
          rows.map((x) =>
            h(
              'div',
              { class: 'item' },
              h('span', { class: 'when', style: 'width:auto;min-width:96px', text: x.date_from === x.date_to ? fmtDate(x.date_from) : `${fmtDate(x.date_from)} → ${fmtDate(x.date_to)}` }),
              h('span', { class: 'what', text: `${x.employee_name || 'Todos'}${x.note ? ` · ${x.note}` : ''}` }),
              h('span', { class: 'chip info', text: KIND_LABELS[x.kind] || x.kind }),
              confirmButton('Quitar', async () => {
                await guard(() => api(`/api/admin/exceptions/${x.id}`, { method: 'DELETE' }));
                await load();
              })
            )
          )
        )
      )
    );
  }

  panel.append(
    h(
      'form',
      {
        class: 'card',
        onsubmit: async (ev) => {
          ev.preventDefault();
          err.classList.add('hidden');
          try {
            await guard(() =>
              api('/api/admin/exceptions', {
                method: 'POST',
                body: { kind: kind.value, employee_id: emp.value || null, date_from: from.value, date_to: to.value, note: note.value },
              })
            );
            note.value = '';
            await load();
          } catch (e) {
            err.textContent = e.message;
            err.classList.remove('hidden');
          }
        },
      },
      h('h2', { text: 'Registrar incidencia' }),
      h('p', { class: 'muted small', text: 'Los días con incidencia no cuentan como falta. Los festivos aplican a todo el personal.' }),
      h('div', { class: 'form-grid' }, h('label', {}, 'Tipo', kind), h('label', {}, 'Empleado', emp), h('label', {}, 'Desde', from), h('label', {}, 'Hasta', to), h('label', {}, 'Nota', note)),
      err,
      h('div', {}, h('button', { class: 'btn primary', type: 'submit', text: 'Registrar' }))
    ),
    list
  );
  await load();
}

// ---------------------------------------------------------------------------
// Ajustes
// ---------------------------------------------------------------------------
async function tabAjustes(panel) {
  const s = ctx.settings;
  const field = (id, type, value, extra = {}) => h('input', { id, type, value: value == null ? '' : String(value), required: true, ...extra });
  const name = field('a-nombre', 'text', s.site_name, { maxlength: '80' });
  const lat = field('a-lat', 'number', s.site_lat, { step: 'any', inputmode: 'decimal' });
  const lng = field('a-lng', 'number', s.site_lng, { step: 'any', inputmode: 'decimal' });
  const radius = field('a-radio', 'number', s.site_radius_m, { min: '20', max: '2000' });
  const acc = field('a-precision', 'number', s.max_accuracy_m, { min: '10', max: '500' });
  const tol = field('a-tolerancia', 'number', s.late_tolerance_min, { min: '0', max: '120' });
  const brk = field('a-descanso', 'number', s.break_min, { min: '0', max: '180' });
  const early = field('a-anticipo', 'number', s.early_window_min, { min: '0', max: '480' });
  const msg = h('p', { class: 'notice hidden' });
  const geoBtn = h('button', { class: 'btn', type: 'button', text: 'Usar mi ubicación actual' });

  geoBtn.addEventListener('click', async () => {
    geoBtn.disabled = true;
    msg.className = 'notice';
    msg.textContent = 'Obteniendo ubicación… para mejor precisión hazlo en el centro de trabajo, en un lugar abierto.';
    try {
      const pos = await getBestPosition({ goodEnough: 15, timeout: 25000 });
      lat.value = pos.coords.latitude.toFixed(6);
      lng.value = pos.coords.longitude.toFixed(6);
      msg.textContent = `Ubicación tomada con precisión de ±${Math.round(pos.coords.accuracy)} m. Revisa los datos y guarda.`;
    } catch (e) {
      msg.className = 'notice bad';
      msg.textContent = geoErrorMessage(e);
    }
    geoBtn.disabled = false;
  });

  panel.append(
    h(
      'form',
      {
        class: 'card',
        onsubmit: async (ev) => {
          ev.preventDefault();
          msg.className = 'notice hidden';
          try {
            const saved = await guard(() =>
              api('/api/admin/settings', {
                method: 'PUT',
                body: {
                  site_name: name.value,
                  site_lat: lat.value,
                  site_lng: lng.value,
                  site_radius_m: radius.value,
                  max_accuracy_m: acc.value,
                  late_tolerance_min: tol.value,
                  break_min: brk.value,
                  early_window_min: early.value,
                },
              })
            );
            if (!saved) return;
            Object.assign(ctx.settings, saved);
            msg.className = 'notice ok';
            msg.textContent = 'Ajustes guardados.';
          } catch (e) {
            msg.className = 'notice bad';
            msg.textContent = e.message;
          }
        },
      },
      h('h2', { text: 'Centro de trabajo' }),
      h('p', { class: 'muted small', text: 'Las checadas solo se aceptan dentro del radio y con la precisión de GPS indicada. Lo más sencillo es abrir esta página desde tu celular, estando en el centro de trabajo, y tocar "Usar mi ubicación actual".' }),
      h('div', { class: 'form-grid' }, h('label', {}, 'Nombre', name), h('label', {}, 'Latitud', lat), h('label', {}, 'Longitud', lng)),
      h('div', {}, geoBtn),
      h(
        'div',
        { class: 'form-grid' },
        h('label', {}, 'Radio permitido (metros)', radius, h('span', { class: 'hint', text: 'Distancia máxima al punto central.' })),
        h('label', {}, 'Precisión máxima del GPS (metros)', acc, h('span', { class: 'hint', text: 'Si el GPS del celular es menos preciso, se rechaza la checada.' }))
      ),
      h('h2', { text: 'Reglas de asistencia' }),
      h(
        'div',
        { class: 'form-grid' },
        h('label', {}, 'Tolerancia de retardo (minutos)', tol, h('span', { class: 'hint', text: 'Pasada la hora de entrada más esta tolerancia, cuenta como retardo.' })),
        h('label', {}, 'Descanso descontado (minutos)', brk, h('span', { class: 'hint', text: 'Se resta de jornadas mayores a 6 h. Usa 0 si no descuentas comida.' })),
        h('label', {}, 'Anticipación permitida (minutos)', early, h('span', { class: 'hint', text: 'Cuánto antes de su hora pueden registrar la entrada.' }))
      ),
      msg,
      h('div', {}, h('button', { class: 'btn primary', type: 'submit', text: 'Guardar ajustes' }))
    )
  );
}

// ---------------------------------------------------------------------------
async function boot() {
  try {
    const sess = await api('/api/admin/session');
    if (!sess.admin) return renderLogin();
    ctx.settings = await api('/api/admin/settings');
    renderShell();
    // Si aún no se configura la ubicación, se lleva directo a Ajustes.
    await showTab(ctx.settings.site_lat == null ? 'ajustes' : ctx.tab);
  } catch (e) {
    if (e.status === 401) return renderLogin();
    clear(app);
    app.append(notice('bad', e.message));
  }
}

boot();
