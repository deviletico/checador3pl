'use strict';

// Utilidades compartidas por la pantalla del empleado y el panel de administración.

async function api(path, opts = {}) {
  const res = await fetch(path, {
    method: opts.method || 'GET',
    headers: opts.body ? { 'Content-Type': 'application/json' } : undefined,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    credentials: 'same-origin',
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* sin cuerpo JSON */
  }
  if (!res.ok) {
    const err = new Error((data && data.message) || 'No se pudo conectar con el servidor.');
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

// Crea elementos del DOM sin usar innerHTML (los nombres y notas son texto del usuario).
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'text') el.textContent = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'value' || k === 'checked' || k === 'selected' || k === 'disabled') el[k] = v;
    else if (v === true) el.setAttribute(k, '');
    else el.setAttribute(k, v);
  }
  for (const kid of kids.flat(Infinity)) {
    if (kid == null || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return el;
}

function clear(el) {
  while (el.firstChild) el.removeChild(el.firstChild);
  return el;
}

const MONTHS = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
const WEEKDAYS = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
const MONTH_NAMES = [
  'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
  'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre',
];

function fmtDate(ymd) {
  const [y, m, d] = ymd.split('-').map(Number);
  const wd = new Date(Date.UTC(y, m - 1, d)).getUTCDay();
  return `${WEEKDAYS[wd]} ${d} ${MONTHS[m - 1]}`;
}

function fmtMonth(ym) {
  const [y, m] = ym.split('-').map(Number);
  return `${MONTH_NAMES[m - 1]} ${y}`;
}

function shiftMonth(ym, delta) {
  const [y, m] = ym.split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1 + delta, 1));
  return `${t.getUTCFullYear()}-${String(t.getUTCMonth() + 1).padStart(2, '0')}`;
}

function fmtHours(minutes) {
  const m = Math.max(0, Math.round(minutes || 0));
  return `${Math.floor(m / 60)}:${String(m % 60).padStart(2, '0')}`;
}

const STATUS = {
  asistencia: { label: 'Asistencia', cls: 'ok' },
  retardo: { label: 'Retardo', cls: 'warn' },
  falta: { label: 'Falta', cls: 'bad' },
  pendiente: { label: 'Pendiente', cls: '' },
  justificada: { label: 'Falta justificada', cls: 'info' },
  vacaciones: { label: 'Vacaciones', cls: 'info' },
  incapacidad: { label: 'Incapacidad', cls: 'info' },
  descanso: { label: 'Descanso', cls: 'info' },
  festivo: { label: 'Festivo', cls: 'info' },
};

function statusChip(status) {
  const s = STATUS[status] || { label: status, cls: '' };
  return h('span', { class: `chip ${s.cls}`, text: s.label });
}

function initials(name) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0].toUpperCase())
    .join('');
}

function avatar(employee, size = '') {
  if (employee.photo_url) {
    return h('img', {
      class: `avatar ${size}`,
      src: employee.photo_url,
      alt: `Foto de ${employee.name}`,
      width: size === 'lg' ? 96 : size === 'sm' ? 38 : 56,
      height: size === 'lg' ? 96 : size === 'sm' ? 38 : 56,
    });
  }
  return h('div', { class: `avatar ${size}`, 'aria-hidden': 'true', text: initials(employee.name) });
}

// Reduce la foto a un JPEG de máx. 480 px para guardarla ligera (≈ 40-90 KB).
function photoToDataUrl(file, maxSide = 480, quality = 0.82) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
      const w = Math.round(img.width * scale);
      const hgt = Math.round(img.height * scale);
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = hgt;
      canvas.getContext('2d').drawImage(img, 0, 0, w, hgt);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('No se pudo leer la imagen.'));
    };
    img.src = url;
  });
}

// Lectura de GPS de alta precisión: espera a que mejore la señal y devuelve la mejor.
function getBestPosition({ goodEnough = 25, timeout = 20000, onProgress } = {}) {
  return new Promise((resolve, reject) => {
    if (!('geolocation' in navigator)) {
      reject({ code: 'unsupported' });
      return;
    }
    let best = null;
    let watchId = null;
    let finished = false;
    const finish = (err) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      if (watchId != null) navigator.geolocation.clearWatch(watchId);
      if (best) resolve(best);
      else reject(err || { code: 3 });
    };
    const timer = setTimeout(() => finish(), timeout);
    watchId = navigator.geolocation.watchPosition(
      (pos) => {
        if (!best || pos.coords.accuracy < best.coords.accuracy) best = pos;
        if (onProgress) onProgress(best.coords.accuracy);
        if (best.coords.accuracy <= goodEnough) finish();
      },
      (err) => {
        // Permiso denegado u hardware no disponible: no tiene caso seguir esperando.
        if (err.code === 1 || !best) {
          finished = true;
          clearTimeout(timer);
          navigator.geolocation.clearWatch(watchId);
          reject(err);
        }
      },
      { enableHighAccuracy: true, maximumAge: 0, timeout }
    );
  });
}

function geoErrorMessage(err) {
  if (err && err.code === 'unsupported') return 'Este navegador no permite obtener la ubicación.';
  if (err && err.code === 1) {
    return 'No diste permiso de ubicación. Actívalo para este sitio en los ajustes del navegador y vuelve a intentar.';
  }
  if (err && err.code === 2) return 'No se pudo determinar tu ubicación. Activa el GPS e inténtalo de nuevo.';
  return 'Se agotó el tiempo para obtener tu ubicación. Sal a un lugar abierto e inténtalo de nuevo.';
}
