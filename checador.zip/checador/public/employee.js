'use strict';

// Pantalla del empleado: inicio de sesión con PIN, checada con GPS y resumen del mes.

const app = document.getElementById('app');

const state = {
  cfg: null,
  status: null,
  clockOffset: 0,
  month: null,
  report: null,
  busy: false,
  result: null,
  progress: '',
};

let clockTimer = null;
let clockEl = null;

function serverNow() {
  return new Date(Date.now() + state.clockOffset);
}

function tickClock() {
  if (!clockEl || !state.cfg) return;
  clockEl.textContent = new Intl.DateTimeFormat('es-MX', {
    timeZone: state.cfg.tz,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
  }).format(serverNow());
}

function startClock() {
  clearInterval(clockTimer);
  tickClock();
  clockTimer = setInterval(tickClock, 1000);
}

// ---------------------------------------------------------------------------
// Inicio de sesión
// ---------------------------------------------------------------------------
async function renderLogin(message) {
  clearInterval(clockTimer);
  clear(app);

  let people = [];
  try {
    people = await api('/api/employees/public');
  } catch (e) {
    message = e.message;
  }

  const select = h(
    'select',
    { id: 'emp', required: true },
    h('option', { value: '', text: 'Selecciona tu nombre' }),
    people.map((p) => h('option', { value: String(p.id), text: p.name }))
  );
  const pin = h('input', {
    id: 'pin',
    type: 'password',
    inputmode: 'numeric',
    pattern: '[0-9]*',
    maxlength: '6',
    autocomplete: 'current-password',
    required: true,
    placeholder: '••••',
  });
  const err = h('p', { class: `notice bad ${message ? '' : 'hidden'}`, role: 'alert', text: message || '' });
  const btn = h('button', { class: 'btn primary', type: 'submit', text: 'Entrar' });

  const form = h(
    'form',
    {
      class: 'card',
      onsubmit: async (ev) => {
        ev.preventDefault();
        btn.disabled = true;
        err.classList.add('hidden');
        try {
          await api('/api/login', { method: 'POST', body: { employee_id: Number(select.value), pin: pin.value } });
          await boot();
        } catch (e) {
          err.textContent = e.message;
          err.classList.remove('hidden');
          pin.value = '';
          btn.disabled = false;
        }
      },
    },
    h('div', {}, h('h1', { text: 'Checador' }), h('p', { class: 'muted', text: 'Registra tu entrada y salida.' })),
    h('label', {}, 'Nombre', select),
    h('label', {}, 'PIN', pin),
    err,
    btn
  );
  app.append(form);
  if (!people.length && !message) {
    app.prepend(h('p', { class: 'notice warn', text: 'Aún no hay personal registrado. Pide al administrador que te dé de alta.' }));
  }
}

// ---------------------------------------------------------------------------
// Pantalla principal
// ---------------------------------------------------------------------------
async function loadStatus() {
  const t0 = Date.now();
  const s = await api('/api/me/status');
  const t1 = Date.now();
  state.clockOffset = Date.parse(s.server_time) - (t0 + t1) / 2;
  state.status = s;
  if (!state.month) state.month = s.month.month;
  return s;
}

async function loadReport() {
  state.report = await api(`/api/me/report?month=${state.month}`);
}

function describeToday(s) {
  const t = s.today;
  if (!t.workday) return { text: 'Hoy es domingo: no es día laborable.', cls: '' };
  const inP = t.punches.find((p) => p.type === 'in');
  const outP = [...t.punches].reverse().find((p) => p.type === 'out');
  if (t.next === 'in') return { text: 'Aún no registras tu entrada de hoy.', cls: '' };
  if (t.next === 'out') return { text: `Entrada registrada a las ${inP.time}. Falta tu salida.`, cls: 'ok' };
  return { text: `Jornada completa: ${inP.time} a ${outP.time}.`, cls: 'ok' };
}

function punchLabel(next) {
  if (next === 'in') return 'Registrar entrada';
  if (next === 'out') return 'Registrar salida';
  if (next === 'done') return 'Jornada completa';
  return 'Hoy no se labora';
}

async function doPunch() {
  if (state.busy) return;
  state.busy = true;
  state.result = null;
  state.progress = 'Obteniendo tu ubicación…';
  render();
  try {
    const pos = await getBestPosition({
      goodEnough: 25,
      onProgress: (acc) => {
        state.progress = `Obteniendo tu ubicación… precisión ±${Math.round(acc)} m`;
        const el = document.getElementById('progress');
        if (el) el.textContent = state.progress;
      },
    });
    state.progress = 'Validando tu ubicación…';
    const el = document.getElementById('progress');
    if (el) el.textContent = state.progress;

    const r = await api('/api/punch', {
      method: 'POST',
      body: {
        lat: pos.coords.latitude,
        lng: pos.coords.longitude,
        accuracy: pos.coords.accuracy,
        // La hora del GPS se corrige con el reloj del servidor para tolerar relojes mal ajustados.
        position_ts: pos.timestamp + state.clockOffset,
      },
    });
    state.result = { ok: true, ...r };
  } catch (e) {
    // Los errores del servidor traen `status`; los demás vienen del GPS del dispositivo.
    state.result = { ok: false, message: e && e.status ? e.message : geoErrorMessage(e) };
  }
  state.busy = false;
  state.progress = '';
  try {
    await loadStatus();
    await loadReport();
  } catch (e) {
    if (e.status === 401) return renderLogin('Tu sesión terminó. Inicia sesión de nuevo.');
  }
  render();
}

function resultNotice() {
  const r = state.result;
  if (!r) return null;
  if (!r.ok) return h('div', { class: 'notice bad', role: 'alert' }, h('strong', { text: 'No se registró' }), r.message);
  const what = r.type === 'in' ? 'Entrada' : 'Salida';
  const detail = `${r.time} · a ${r.distance_m} m del centro de trabajo (precisión ±${r.accuracy_m} m)`;
  if (r.type === 'in' && r.late) {
    return h(
      'div',
      { class: 'notice warn', role: 'status' },
      h('strong', { text: `${what} registrada con retardo` }),
      `Llegaste ${r.minutes_late} min después de tu hora de entrada. `,
      detail
    );
  }
  return h('div', { class: 'notice ok', role: 'status' }, h('strong', { text: `${what} registrada` }), detail);
}

function monthTiles(totals) {
  return h(
    'div',
    { class: 'tiles' },
    h('div', { class: 'tile' }, h('b', { text: totals.dias_trabajados }), h('span', { text: 'Días trabajados' })),
    h('div', { class: `tile ${totals.retardos ? 'warn' : ''}` }, h('b', { text: totals.retardos }), h('span', { text: 'Retardos' })),
    h('div', { class: `tile ${totals.faltas ? 'bad' : ''}` }, h('b', { text: totals.faltas }), h('span', { text: 'Faltas' })),
    h('div', { class: 'tile' }, h('b', { text: fmtHours(totals.minutos_trabajados) }), h('span', { text: 'Horas trabajadas' }))
  );
}

function dayRow(d) {
  let detail = '';
  if (d.entrada) {
    detail = `${d.entrada} – ${d.salida || (d.sin_salida ? 'sin salida' : '…')}`;
    if (d.salida) detail += ` · ${fmtHours(d.minutos_trabajados)} h`;
    if (d.minutos_retardo) detail += ` · +${d.minutos_retardo} min`;
  } else if (d.note) {
    detail = d.note;
  }
  return h(
    'div',
    { class: 'item' },
    h('span', { class: 'when', text: fmtDate(d.date) }),
    h('span', { class: 'what', text: detail }),
    statusChip(d.status)
  );
}

function render() {
  const s = state.status;
  if (!s) return;
  clear(app);
  const e = s.employee;
  const today = describeToday(s);
  const canPunch = (s.today.next === 'in' || s.today.next === 'out') && s.configured;

  clockEl = h('div', { class: 'clock', 'aria-label': 'Hora actual' });

  const header = h(
    'div',
    { class: 'card' },
    h(
      'div',
      { class: 'row' },
      avatar(e),
      h(
        'div',
        { class: 'grow' },
        h('h1', { text: e.name }),
        h('p', { class: 'muted small', text: `Turno ${e.shift_label.toLowerCase()} · ${e.shift_start} a ${e.shift_end}` })
      ),
      h('button', {
        class: 'btn ghost sm',
        text: 'Salir',
        onclick: async () => {
          await api('/api/logout', { method: 'POST', body: {} });
          state.status = null;
          state.month = null;
          renderLogin();
        },
      })
    )
  );

  const punchCard = h(
    'div',
    { class: 'card' },
    h('div', { class: 'row between wrap-sm' }, clockEl, h('p', { class: 'muted small', text: `${fmtDate(s.today.date)} · ${s.site_name}` })),
    h('p', { class: today.cls === 'ok' ? '' : 'muted', text: today.text }),
    !s.configured
      ? h('p', { class: 'notice warn', text: 'El administrador aún no configura la ubicación del centro de trabajo.' })
      : null,
    h('button', {
      class: 'btn primary punch-btn',
      disabled: !canPunch || state.busy,
      onclick: doPunch,
      text: state.busy ? 'Un momento…' : punchLabel(s.today.next),
    }),
    state.busy
      ? h('div', { class: 'row' }, h('div', { class: 'spinner' }), h('p', { id: 'progress', class: 'muted small', text: state.progress }))
      : null,
    resultNotice(),
    s.today.punches.length
      ? h(
          'div',
          { class: 'list' },
          s.today.punches.map((p) =>
            h(
              'div',
              { class: 'item' },
              h('span', { class: 'when', text: p.time }),
              h('span', { class: 'what', text: p.distance_m == null ? 'Registro manual' : `A ${p.distance_m} m del centro de trabajo` }),
              h('span', { class: `chip ${p.type === 'in' ? 'ok' : ''}`, text: p.type === 'in' ? 'Entrada' : 'Salida' })
            )
          )
        )
      : null
  );

  const r = state.report;
  const monthCard = h(
    'div',
    { class: 'card' },
    h(
      'div',
      { class: 'row between' },
      h('button', { class: 'btn sm', 'aria-label': 'Mes anterior', text: '‹', onclick: () => changeMonth(-1) }),
      h('h2', { text: fmtMonth(state.month) }),
      h('button', {
        class: 'btn sm',
        'aria-label': 'Mes siguiente',
        text: '›',
        disabled: state.month >= s.month.month,
        onclick: () => changeMonth(1),
      })
    ),
    r ? monthTiles(r.totals) : null,
    r && r.days.length
      ? h('div', { class: 'list' }, [...r.days].reverse().map(dayRow))
      : h('p', { class: 'empty', text: 'Sin registros en este mes.' })
  );

  app.append(header, punchCard, monthCard);
  startClock();
}

async function changeMonth(delta) {
  state.month = shiftMonth(state.month, delta);
  try {
    await loadReport();
  } catch (e) {
    if (e.status === 401) return renderLogin('Tu sesión terminó. Inicia sesión de nuevo.');
  }
  render();
}

async function boot() {
  try {
    state.cfg = await api('/api/config');
    await loadStatus();
    await loadReport();
    render();
  } catch (e) {
    if (e.status === 401 || e.status === 403) {
      renderLogin(e.status === 403 ? e.message : '');
    } else {
      clear(app);
      app.append(h('p', { class: 'notice bad', text: e.message }));
    }
  }
}

// Al volver a la pestaña se refresca el estado (por si pasó la medianoche o cambió algo).
document.addEventListener('visibilitychange', async () => {
  if (document.visibilityState === 'visible' && state.status && !state.busy) {
    try {
      await loadStatus();
      await loadReport();
      render();
    } catch {
      /* se ignora; el siguiente intento mostrará el error */
    }
  }
});

boot();
