'use strict';

// Prueba de punta a punta del servidor con un reloj simulado y una base de datos temporal.

const fs = require('fs');
const os = require('os');
const path = require('path');
const test = require('node:test');
const assert = require('node:assert/strict');

process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'checador-test-'));
process.env.ADMIN_PASSWORD = 'clave-de-prueba';

const SITE = { lat: 19.0, lng: -99.0 };
// Jueves 19 de noviembre de 2026, 06:45 hora de Ciudad de México (UTC-6).
const T0 = Date.parse('2026-11-19T12:45:00Z');

let server;
let base;
let adminCookie;
let empCookie;
let empId;
let otherId;

test.before(async () => {
  test.mock.timers.enable({ apis: ['Date'], now: T0 });
  const { app } = require('../server');
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', resolve);
  });
  base = `http://127.0.0.1:${server.address().port}`;
});

test.after(() => {
  server.close();
  test.mock.timers.reset();
  fs.rmSync(process.env.DATA_DIR, { recursive: true, force: true });
});

async function call(method, url, body, cookie) {
  const res = await fetch(base + url, {
    method,
    headers: {
      ...(body ? { 'Content-Type': 'application/json' } : {}),
      ...(cookie ? { Cookie: cookie } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const type = res.headers.get('content-type') || '';
  const data = type.includes('json') ? await res.json() : await res.text();
  const setCookie = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
  const cookieOut = setCookie.length ? setCookie[0].split(';')[0] : null;
  return { status: res.status, data, cookie: cookieOut, headers: res.headers };
}

const here = (over = {}) => ({
  lat: SITE.lat,
  lng: SITE.lng,
  accuracy: 12,
  position_ts: Date.now(),
  ...over,
});

test('el administrador inicia sesión y configura la ubicación', async () => {
  const bad = await call('POST', '/api/admin/login', { password: 'incorrecta' });
  assert.equal(bad.status, 401);

  const ok = await call('POST', '/api/admin/login', { password: 'clave-de-prueba' });
  assert.equal(ok.status, 200);
  adminCookie = ok.cookie;
  assert.ok(adminCookie.startsWith('adm='));

  const noAuth = await call('GET', '/api/admin/settings');
  assert.equal(noAuth.status, 401);

  const invalid = await call('PUT', '/api/admin/settings', { site_name: 'X', site_lat: 200, site_lng: 0, site_radius_m: 150, max_accuracy_m: 80, late_tolerance_min: 10, break_min: 0, early_window_min: 120 }, adminCookie);
  assert.equal(invalid.status, 400);

  const saved = await call('PUT', '/api/admin/settings', {
    site_name: 'Sucursal Centro', site_lat: SITE.lat, site_lng: SITE.lng, site_radius_m: 100,
    max_accuracy_m: 50, late_tolerance_min: 10, break_min: 0, early_window_min: 120,
  }, adminCookie);
  assert.equal(saved.status, 200);
  assert.equal(saved.data.site_radius_m, 100);
});

test('alta de personal con foto, turno y PIN', async () => {
  const shortPin = await call('POST', '/api/admin/employees', { name: 'Ana', shift: 'matutino', start_date: '2026-11-19', pin: '12' }, adminCookie);
  assert.equal(shortPin.status, 400);

  const badShift = await call('POST', '/api/admin/employees', { name: 'Ana', shift: 'nocturno', start_date: '2026-11-19', pin: '1234' }, adminCookie);
  assert.equal(badShift.status, 400);

  const fakeJpeg = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(800, 1)]);
  const photo = `data:image/jpeg;base64,${fakeJpeg.toString('base64')}`;

  const ana = await call('POST', '/api/admin/employees', { name: 'Ana López', shift: 'matutino', start_date: '2026-11-19', pin: '1234', photo }, adminCookie);
  assert.equal(ana.status, 201);
  assert.ok(ana.data.photo_url);
  empId = ana.data.id;

  const luis = await call('POST', '/api/admin/employees', { name: 'Luis Pérez', shift: 'cierre', start_date: '2026-11-19', pin: '4321' }, adminCookie);
  assert.equal(luis.status, 201);
  otherId = luis.data.id;

  const notJpeg = await call('POST', '/api/admin/employees', { name: 'Eva', shift: 'intermedio', start_date: '2026-11-19', pin: '9999', photo: 'data:image/png;base64,AAAA' }, adminCookie);
  assert.equal(notJpeg.status, 400);

  const list = await call('GET', '/api/employees/public');
  assert.deepEqual(list.data.map((p) => p.name), ['Ana López', 'Luis Pérez']);
  assert.equal(list.data[0].pin_hash, undefined);
});

test('inicio de sesión del empleado y bloqueo por intentos fallidos', async () => {
  const wrong = await call('POST', '/api/login', { employee_id: otherId, pin: '0000' });
  assert.equal(wrong.status, 401);

  const noSession = await call('GET', '/api/me/status');
  assert.equal(noSession.status, 401);

  const ok = await call('POST', '/api/login', { employee_id: empId, pin: '1234' });
  assert.equal(ok.status, 200);
  empCookie = ok.cookie;

  // Cinco fallos seguidos bloquean temporalmente a ese empleado.
  let last;
  for (let i = 0; i < 6; i++) last = await call('POST', '/api/login', { employee_id: otherId, pin: '1111' });
  assert.equal(last.status, 429);
});

test('un empleado no puede entrar al panel ni ver fotos ajenas', async () => {
  assert.equal((await call('GET', '/api/admin/employees', null, empCookie)).status, 401);
  assert.equal((await call('GET', `/api/photo/${otherId}`, null, empCookie)).status, 401);
  assert.equal((await call('GET', `/api/photo/${empId}`, null, empCookie)).status, 200);
  assert.equal((await call('GET', `/api/photo/${empId}`)).status, 401);
});

test('la checada rechaza ubicaciones inválidas, imprecisas, viejas o fuera de la zona', async () => {
  const far = await call('POST', '/api/punch', here({ lat: SITE.lat + 0.002 }), empCookie); // ~222 m
  assert.equal(far.status, 403);
  assert.equal(far.data.code, 'fuera_de_zona');

  const inaccurate = await call('POST', '/api/punch', here({ accuracy: 120 }), empCookie);
  assert.equal(inaccurate.status, 422);
  assert.equal(inaccurate.data.code, 'precision');

  const stale = await call('POST', '/api/punch', here({ position_ts: Date.now() - 5 * 60 * 1000 }), empCookie);
  assert.equal(stale.status, 400);
  assert.equal(stale.data.code, 'ubicacion_vieja');

  const garbage = await call('POST', '/api/punch', { lat: 'x', lng: 1, accuracy: 3, position_ts: Date.now() }, empCookie);
  assert.equal(garbage.status, 400);

  const status = await call('GET', '/api/me/status', null, empCookie);
  assert.equal(status.data.today.next, 'in');
  assert.equal(status.data.today.punches.length, 0);
});

test('entrada con retardo, salida y jornada completa', async () => {
  // 06:45 con tolerancia de 10 min en turno de 06:30 → retardo de 15 min.
  const entrada = await call('POST', '/api/punch', here({ lat: SITE.lat + 0.0003 }), empCookie); // ~33 m
  assert.equal(entrada.status, 200);
  assert.equal(entrada.data.type, 'in');
  assert.equal(entrada.data.time, '06:45');
  assert.equal(entrada.data.late, true);
  assert.equal(entrada.data.minutes_late, 15);
  assert.ok(entrada.data.distance_m >= 30 && entrada.data.distance_m <= 36);

  // Doble toque inmediato.
  test.mock.timers.setTime(T0 + 30 * 1000);
  const rapido = await call('POST', '/api/punch', here(), empCookie);
  assert.equal(rapido.status, 429);

  // 15:35 hora local = 21:35 UTC.
  test.mock.timers.setTime(Date.parse('2026-11-19T21:35:00Z'));
  const salida = await call('POST', '/api/punch', here(), empCookie);
  assert.equal(salida.status, 200);
  assert.equal(salida.data.type, 'out');
  assert.equal(salida.data.time, '15:35');

  const otra = await call('POST', '/api/punch', here(), empCookie);
  assert.equal(otra.status, 409);
  assert.equal(otra.data.code, 'completo');

  const me = await call('GET', '/api/me/status', null, empCookie);
  assert.equal(me.data.today.next, 'done');
  assert.equal(me.data.month.totals.retardos, 1);
  assert.equal(me.data.month.totals.dias_trabajados, 1);
  assert.equal(me.data.month.totals.minutos_trabajados, 530); // 06:45 a 15:35
  assert.equal(me.data.month.totals.faltas, 0);
});

test('no se permite checar entrada demasiado temprano ni en domingo', async () => {
  const luisLogin = await call('POST', '/api/admin/employees/' + otherId, null, adminCookie).catch(() => null);
  assert.ok(luisLogin === null || luisLogin.status >= 400);

  // Reinicia el bloqueo creando una sesión nueva con otro empleado (turno de cierre 11:00, desde 09:00).
  const eva = await call('POST', '/api/admin/employees', { name: 'Eva Ruiz', shift: 'cierre', start_date: '2026-11-19', pin: '5555' }, adminCookie);
  const login = await call('POST', '/api/login', { employee_id: eva.data.id, pin: '5555' });
  assert.equal(login.status, 200);

  // Viernes 20 a las 07:00 locales: faltan 4 h para las 11:00, fuera de la ventana de 2 h.
  test.mock.timers.setTime(Date.parse('2026-11-20T13:00:00Z'));
  const temprano = await call('POST', '/api/punch', here(), login.cookie);
  assert.equal(temprano.status, 422);
  assert.equal(temprano.data.code, 'muy_temprano');

  // Domingo 22 de noviembre.
  test.mock.timers.setTime(Date.parse('2026-11-22T17:00:00Z'));
  const domingo = await call('POST', '/api/punch', here(), login.cookie);
  assert.equal(domingo.status, 422);
  assert.equal(domingo.data.code, 'domingo');
});

test('reporte, CSV, incidencias y correcciones manuales del administrador', async () => {
  // Lunes 23 a mediodía: Ana faltó el viernes 20 y el sábado 21.
  test.mock.timers.setTime(Date.parse('2026-11-23T18:00:00Z'));
  // La sesión del administrador dura 12 h, así que tras varios días simulados se vuelve a entrar.
  const expired = await call('GET', '/api/admin/settings', null, adminCookie);
  assert.equal(expired.status, 401);
  adminCookie = (await call('POST', '/api/admin/login', { password: 'clave-de-prueba' })).cookie;
  let rep = await call('GET', '/api/admin/report?from=2026-11-01&to=2026-11-30', null, adminCookie);
  assert.equal(rep.status, 200);
  const ana = rep.data.rows.find((r) => r.employee.id === empId);
  assert.equal(ana.totals.dias_trabajados, 1);
  assert.equal(ana.totals.faltas, 2);
  assert.equal(ana.totals.retardos, 1);

  // Falta justificada el viernes y festivo el sábado.
  const just = await call('POST', '/api/admin/exceptions', { kind: 'justificada', employee_id: empId, date_from: '2026-11-20', date_to: '2026-11-20', note: 'Cita médica' }, adminCookie);
  assert.equal(just.status, 201);
  const fest = await call('POST', '/api/admin/exceptions', { kind: 'festivo', employee_id: null, date_from: '2026-11-21', date_to: '2026-11-21', note: 'Prueba' }, adminCookie);
  assert.equal(fest.status, 201);
  const soloFestivoGeneral = await call('POST', '/api/admin/exceptions', { kind: 'vacaciones', employee_id: null, date_from: '2026-11-21', date_to: '2026-11-21' }, adminCookie);
  assert.equal(soloFestivoGeneral.status, 400);

  rep = await call('GET', '/api/admin/report?from=2026-11-01&to=2026-11-30', null, adminCookie);
  const ana2 = rep.data.rows.find((r) => r.employee.id === empId);
  assert.equal(ana2.totals.faltas, 0);
  assert.equal(ana2.totals.justificadas, 1);

  const csv = await call('GET', '/api/admin/report.csv?from=2026-11-01&to=2026-11-30', null, adminCookie);
  assert.equal(csv.status, 200);
  // fetch().text() descarta el BOM, así que se verifica en bytes que Excel lo recibe.
  const raw = new Uint8Array(await (await fetch(base + '/api/admin/report.csv?from=2026-11-01&to=2026-11-30', { headers: { Cookie: adminCookie } })).arrayBuffer());
  assert.deepEqual([...raw.slice(0, 3)], [0xef, 0xbb, 0xbf]);
  assert.ok(csv.data.startsWith('"Empleado"'));
  assert.ok(csv.data.includes('"Ana López"'));
  assert.ok(csv.data.includes('"8:50"')); // 530 min

  const badRange = await call('GET', '/api/admin/report?from=2026-12-01&to=2026-11-01', null, adminCookie);
  assert.equal(badRange.status, 400);

  // Corrección manual: salida olvidada de Luis el lunes 23 (sin motivo se rechaza).
  const noNote = await call('POST', '/api/admin/punches', { employee_id: otherId, type: 'in', date: '2026-11-23', time: '11:05' }, adminCookie);
  assert.equal(noNote.status, 400);
  const manual = await call('POST', '/api/admin/punches', { employee_id: otherId, type: 'in', date: '2026-11-23', time: '11:05', note: 'Falló el GPS' }, adminCookie);
  assert.equal(manual.status, 201);

  const detail = await call('GET', `/api/admin/employees/${otherId}/detail?from=2026-11-23&to=2026-11-23`, null, adminCookie);
  assert.equal(detail.data.punches.length, 1);
  assert.equal(detail.data.punches[0].source, 'manual');
  assert.equal(detail.data.punches[0].time, '11:05');
  assert.equal(detail.data.days[0].status, 'asistencia');

  const del = await call('DELETE', `/api/admin/punches/${detail.data.punches[0].id}`, null, adminCookie);
  assert.equal(del.status, 200);

  const today = await call('GET', '/api/admin/today', null, adminCookie);
  assert.equal(today.status, 200);
  assert.equal(today.data.date, '2026-11-23');
});

test('las peticiones que modifican datos deben ser JSON', async () => {
  const res = await fetch(base + '/api/login', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: 'x' });
  assert.equal(res.status, 415);
});
