'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const calc = require('../lib/calc');

const { localToUtc, localParts, summarize, haversineMeters, isLate, minutesLate, isWorkday } = calc;

const settings = { late_tolerance_min: 10, break_min: 0 };
const at = (date, time) => localToUtc(date, time).toISOString();
const emp = (over = {}) => ({ id: 1, shift: 'matutino', start_date: '2026-11-02', ...over });

test('hora local de Ciudad de México (UTC-6)', () => {
  const p = localParts('2026-11-19T12:30:00Z');
  assert.equal(p.date, '2026-11-19');
  assert.equal(p.time, '06:30');
  assert.equal(p.minutes, 390);
});

test('localToUtc es inverso de localParts', () => {
  const d = localToUtc('2026-11-19', '15:45');
  const p = localParts(d);
  assert.equal(p.date, '2026-11-19');
  assert.equal(p.time, '15:45');
});

test('retardo respeta la tolerancia en cada turno', () => {
  // Matutino 06:30, tolerancia 10 min
  assert.equal(isLate(6 * 60 + 40, 'matutino', 10), false);
  assert.equal(isLate(6 * 60 + 41, 'matutino', 10), true);
  // Intermedio 08:00
  assert.equal(isLate(8 * 60 + 10, 'intermedio', 10), false);
  assert.equal(isLate(8 * 60 + 11, 'intermedio', 10), true);
  // Cierre 11:00
  assert.equal(isLate(11 * 60 + 11, 'cierre', 10), true);
  assert.equal(minutesLate(10 * 60 + 50, 'cierre'), 0);
  assert.equal(minutesLate(11 * 60 + 25, 'cierre'), 25);
});

test('solo el domingo no es día laborable', () => {
  assert.equal(isWorkday('2026-11-07'), true); // sábado
  assert.equal(isWorkday('2026-11-08'), false); // domingo
  assert.equal(isWorkday('2026-11-09'), true); // lunes
});

test('distancia haversine (~100 m)', () => {
  const d = haversineMeters(19.0, -99.0, 19.0009, -99.0);
  assert.ok(Math.abs(d - 100.07) < 1, `distancia ${d}`);
  assert.equal(Math.round(haversineMeters(19, -99, 19, -99)), 0);
});

test('resumen semanal: asistencias, retardos, faltas, justificadas y horas', () => {
  const punches = [
    { type: 'in', ts: at('2026-11-02', '06:25') }, // lun a tiempo
    { type: 'out', ts: at('2026-11-02', '15:35') }, // 9:10 h = 550 min
    { type: 'in', ts: at('2026-11-03', '06:50') }, // mar retardo 20 min
    { type: 'out', ts: at('2026-11-03', '15:30') }, // 8:40 h = 520 min
    // mié sin checadas -> falta
    // jue justificada
    { type: 'in', ts: at('2026-11-06', '06:30') }, // vie sin salida
    // sáb sin checadas, turno ya terminó -> falta
  ];
  const exceptions = [
    { employee_id: 1, date_from: '2026-11-05', date_to: '2026-11-05', kind: 'justificada', note: 'Cita' },
  ];
  const r = summarize({
    employee: emp(),
    punches,
    exceptions,
    from: '2026-11-02',
    to: '2026-11-08',
    now: new Date(at('2026-11-07', '18:00')), // sábado 18:00
    settings,
  });
  assert.deepEqual(r.totals, {
    dias_trabajados: 3,
    retardos: 1,
    minutos_retardo: 20,
    faltas: 2,
    justificadas: 1,
    sin_salida: 1,
    minutos_trabajados: 550 + 520,
  });
  assert.equal(r.days.find((d) => d.date === '2026-11-04').status, 'falta');
  assert.equal(r.days.find((d) => d.date === '2026-11-05').status, 'justificada');
  assert.equal(r.days.find((d) => d.date === '2026-11-06').sin_salida, true);
});

test('hoy no cuenta como falta hasta que termina el turno', () => {
  const base = {
    employee: emp({ shift: 'cierre' }), // 11:00 a 20:00
    punches: [],
    exceptions: [],
    from: '2026-11-09',
    to: '2026-11-09',
    settings,
  };
  const during = summarize({ ...base, now: new Date(at('2026-11-09', '12:00')) });
  assert.equal(during.totals.faltas, 0);
  assert.equal(during.days[0].status, 'pendiente');
  const after = summarize({ ...base, now: new Date(at('2026-11-09', '20:30')) });
  assert.equal(after.totals.faltas, 1);
});

test('domingos, festivos y fechas previas al ingreso no generan faltas', () => {
  const r = summarize({
    employee: emp({ start_date: '2026-11-04' }),
    punches: [],
    exceptions: [{ employee_id: null, date_from: '2026-11-06', date_to: '2026-11-06', kind: 'festivo', note: '' }],
    from: '2026-11-02',
    to: '2026-11-08',
    now: new Date(at('2026-11-09', '08:00')),
    settings,
  });
  // Dentro del periodo laborable desde el mié 4: mié, jue, (vie festivo), sáb. Domingo se omite.
  assert.equal(r.totals.faltas, 3);
  assert.equal(r.totals.justificadas, 0);
  assert.equal(r.days.find((d) => d.date === '2026-11-06').status, 'festivo');
  assert.equal(r.days.find((d) => d.date === '2026-11-08'), undefined);
  assert.equal(r.days.find((d) => d.date === '2026-11-03'), undefined);
});

test('descuento de descanso solo en jornadas largas', () => {
  const r = summarize({
    employee: emp(),
    punches: [
      { type: 'in', ts: at('2026-11-02', '06:30') },
      { type: 'out', ts: at('2026-11-02', '15:30') }, // 540 min
      { type: 'in', ts: at('2026-11-03', '06:30') },
      { type: 'out', ts: at('2026-11-03', '09:30') }, // 180 min, sin descuento
    ],
    exceptions: [],
    from: '2026-11-02',
    to: '2026-11-03',
    now: new Date(at('2026-11-04', '08:00')),
    settings: { late_tolerance_min: 10, break_min: 60 },
  });
  assert.equal(r.totals.minutos_trabajados, 480 + 180);
});
